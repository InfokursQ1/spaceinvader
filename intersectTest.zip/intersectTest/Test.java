import greenfoot.*;
public class Test extends World
{
Steuerung st=new Steuerung();
public Test()
{    
super(600, 400, 1);
addObject(st,0,0);
}
}
