import greenfoot.*;
public class Steuerung extends Actor
{
World Welt;
Bullet bum;
Gegner g;  
public void act() 
{

}
public void addedToWorld(World w)
{
Welt=w;
bum=new Bullet();
Welt.addObject(bum,100,100);
g=new Gegner();
Welt.addObject(g,200,200);    
} // addedToWorld
} // class Steuerung
