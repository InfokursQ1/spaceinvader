import greenfoot.*;
public class Bullet extends Actor
{
   
public void act() 
{
Gegner g1=(Gegner)(getOneIntersectingObject(Gegner.class));
if(g1!=null)
{
    System.out.println("Berührt!");
} // if       
}    
}
